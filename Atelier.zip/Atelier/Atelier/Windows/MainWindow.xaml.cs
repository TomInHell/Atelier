﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Atelier
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        AtelierEntities1 entities1 = new AtelierEntities1();
        Appointment appointment = new Appointment();
        public MainWindow()
        {
            InitializeComponent();
            EmploeeRemove.ItemsSource = entities1.Emploee.Select(x => x.Name).ToList();
            EmploeeAdd.ItemsSource = entities1.Emploee.Select(x => x.Name).ToList();
        }

        private void Button_Click(object sender, RoutedEventArgs e) //открыть панель записи
        {
            addPage.Visibility = Visibility.Visible;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e) //открыть панель отмены записи
        {
            removePage1.Visibility = Visibility.Visible;
        }

        private void Button_Click_2(object sender, RoutedEventArgs e) //открыть панель информации
        {
            infoPage1.Visibility = Visibility.Visible;
        }

        private void Button_Click_3(object sender, RoutedEventArgs e) //закрыть панель записи
        {
            addPage.Visibility = Visibility.Hidden;
        }

        private void Button_Click_4(object sender, RoutedEventArgs e) //закрыть панель отмены записи
        {
            removePage1.Visibility = Visibility.Hidden;
        }

        private void Button_Click_5(object sender, RoutedEventArgs e) //закрыть панель информации
        {
            infoPage1.Visibility = Visibility.Hidden;
        }

        private void Button_Click_6(object sender, RoutedEventArgs e) //переход к авторизации администратора
        {
            Windows.Avtorize avtorize = new Windows.Avtorize();
            avtorize.ShowDialog();
        }

        private void Button_Click_7(object sender, RoutedEventArgs e) //записаться
        {
            string pass = PasswordGenerate();
            var add = entities1.Emploee.Where(a => a.Name == EmploeeAdd.SelectedItem.ToString()).FirstOrDefault();
            var appoint = entities1.Appointment.Where(y => y.Emploee_ID == add.ID).FirstOrDefault(); 

            if (FamAdd.Text != "" && NameAdd.Text != "" && MailAdd.Text != "" && EmploeeAdd.Text != null && DataAdd.Text != "")
            {
                if (appoint.Time != Convert.ToDateTime(DataAdd.Text)) 
                {
                    try
                    {
                        appointment.Client_last_name = FamAdd.Text.Trim();
                        appointment.Client_first_name = NameAdd.Text.Trim();
                        appointment.Client_otchestvo_name = OtchAdd.Text.Trim();
                        appointment.Client_mail = MailAdd.Text.Trim();
                        appointment.Emploee_ID = add.ID;
                        appointment.Time = Convert.ToDateTime(DataAdd.Text.Trim());
                        appointment.Password = pass;

                        entities1.Appointment.Add(appointment);

                        SendMail(MailAdd.Text, pass);
                    }
                    catch
                    {
                        MessageBox.Show("Проверьте правильность введенных данных");
                    }
                }
                else
                {
                    MessageBox.Show("Измените время записи, оно уже занято");
                }
            }
            else
            {
                MessageBox.Show("Заполните пустые поля");
            }
        }

        private void Button_Click_8(object sender, RoutedEventArgs e) //отменить запись
        {
            if (FamRemove.Text != "" && EmploeeRemove.Text != "" && DataRemove.Text != "" && PasswordRemove.Text != "")
            {
                var data = Convert.ToDateTime(DataRemove.Text);
                try
                {
                    var add = entities1.Emploee.Where(a => a.Name == EmploeeRemove.SelectedItem.ToString()).FirstOrDefault();
                    var remove = entities1.Appointment.Where(u => u.Client_last_name == FamRemove.Text && u.Time == data && u.Password == PasswordRemove.Text && u.Emploee_ID == add.ID).ToList().FirstOrDefault();

                    entities1.Appointment.Remove(remove);
                    entities1.SaveChanges();

                    MessageBox.Show("Запись удалена");
                }
                catch
                {
                    MessageBox.Show("Проверьте правильность введенных данных");
                }
            }
            else
            {
                MessageBox.Show("Заполните пустые поля");
            }
        }

        private void EmploeeAdd_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {
            DataAdd.Text = null;
            var add = entities1.Emploee.Where(a => a.Name == EmploeeAdd.SelectedItem.ToString()).FirstOrDefault();
            DataAdd.ItemsSource = entities1.Schedule.Where(a => a.Emploee_ID == add.ID).Select(x => x.Time).ToList();
        }

        private void EmploeeRemove_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataRemove.Text = null;
            var add = entities1.Emploee.Where(a => a.Name == EmploeeRemove.SelectedItem.ToString()).FirstOrDefault();
            DataRemove.ItemsSource = entities1.Schedule.Where(a => a.Emploee_ID == add.ID).Select(x => x.Time).ToList();
        }

        public string PasswordGenerate()
        {
            int r, k;
            int passwordLength = 10;
            string password = "";
            char[] upperCase = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
            char[] lowerCase = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };
            char[] numbers = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };
            Random rRandom = new Random();



            for (int i = 0; i < passwordLength; i++)
            {
                r = rRandom.Next(3);

                if (r == 0)
                {
                    k = rRandom.Next(0, 25);
                    password += upperCase[k];
                }

                else if (r == 1)
                {
                    k = rRandom.Next(0, 25);
                    password += lowerCase[k];
                }

                else if (r == 2)
                {
                    k = rRandom.Next(0, 9);
                    password += numbers[k];
                }

            }

            return password;
        }

        public void SendMail(string mail, string pass)
        {
            try
            {
                SmtpClient smtp1 = new SmtpClient("smtp.mail.ru", 25);
                smtp1.Credentials = new NetworkCredential("tamilat2002@mail.ru", "B9L5A2C8K5");
                MailMessage message = new MailMessage();
                message.From = new MailAddress("tamilat2002@mail.ru", "Тамила Тишина");
                message.To.Add(new MailAddress(mail));
                message.Subject = "Запись в ателье";
                message.Body = "Вы записаны в ателье к " + EmploeeAdd.Text + ". Дата записи: " + DataAdd.Text + ". Если вы решите отменить эту запись, примените пароль: " + pass;
                smtp1.EnableSsl = true;
                smtp1.Send(message);

                entities1.SaveChanges();

                MessageBox.Show("Вы записаны."
                            + Environment.NewLine + "Письмо с уточнением даты вашего "
                            + Environment.NewLine + "приема отправлены вам на почту."
                            + Environment.NewLine + "Пароль для удаления записи: " + pass);
            }
            catch
            {
                MessageBox.Show("Что-то не так с вашей почтой");
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Atelier.Windows
{
    /// <summary>
    /// Логика взаимодействия для AdminWin.xaml
    /// </summary>
    public partial class AdminWin : Window
    {
        AtelierEntities1 entities1 = new AtelierEntities1();
        Emploee emploee = new Emploee();
        Schedule schedule = new Schedule();

        public AdminWin()
        {
            InitializeComponent();

            AppointGrid.ItemsSource = entities1.Appointment.ToList();
            EmploeeGrid.ItemsSource = entities1.Emploee.ToList();
            ScheduleGrid.ItemsSource = entities1.Schedule.ToList();
            ComboSchedule.ItemsSource = entities1.Emploee.Select(x => x.Name).ToList();
        } 

        private void Button_Click(object sender, RoutedEventArgs e) //выход из редактирования сотрудников
        {
            redact.Visibility = Visibility.Hidden;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e) //вход в редактирование сотрудников
        {
            redact.Visibility = Visibility.Visible;
        }

        private void Button_Click_2(object sender, RoutedEventArgs e) //выход из редактирования расписания
        {
            redRasp.Visibility = Visibility.Hidden;
        }

        private void Button_Click_3(object sender, RoutedEventArgs e) //вход в редактирование расписания
        {
            redRasp.Visibility = Visibility.Visible;
        }

        private void Button_Click_4(object sender, RoutedEventArgs e) //удаление записей
        {
            var remove = AppointGrid.SelectedItems.Cast<Appointment>().ToList();

            if (MessageBox.Show("Вы уверены, что хотите удалить записи?", "Внимание", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                entities1.Appointment.RemoveRange(remove);
                entities1.SaveChanges();

                AppointGrid.ItemsSource = entities1.Appointment.ToList();
                MessageBox.Show("Записи удалены");
            }
            else
            {
                MessageBox.Show("Записи не удалены))");
            }
        }

        private void Button_Click_5(object sender, RoutedEventArgs e) //удаление сотрудников
        {
            var remove = EmploeeGrid.SelectedItems.Cast<Emploee>().ToList();

            if (MessageBox.Show("Вы уверены, что хотите удалить сотрудников?", "Внимание", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                entities1.Emploee.RemoveRange(remove);
                entities1.SaveChanges();

                EmploeeGrid.ItemsSource = entities1.Emploee.ToList();
                MessageBox.Show("Записи удалены");
            }
            else
            {
                MessageBox.Show("Записи не удалены))");
            }
        }

        private void Button_Click_6(object sender, RoutedEventArgs e) //изменение сотрудников
        {
            if (FIOemploee.Text != "" && SpecEmploee.Text != "") 
            {
                var add = entities1.Emploee.Where(a => a.Name == FIOemploee.Text).FirstOrDefault();

                try
                {
                    if (add != null)
                    {
                        add.Name = FIOemploee.Text.Trim();
                        add.Specialization = SpecEmploee.Text.Trim();
                    }
                    else
                    {
                        emploee.Name = FIOemploee.Text.Trim();
                        emploee.Specialization = SpecEmploee.Text.Trim();

                        entities1.Emploee.Add(emploee);
                    }
                    entities1.SaveChanges();
                    EmploeeGrid.ItemsSource = entities1.Emploee.ToList();
                }
                catch
                {
                    MessageBox.Show("Проверьте правильность введенных данных");
                }
            }
            else
            {
                MessageBox.Show("Заполните пустые поля");
            }
        }

        private void Button_Click_7(object sender, RoutedEventArgs e) //удаление расписания
        {
            var remove = ScheduleGrid.SelectedItems.Cast<Schedule>().ToList();

            if (MessageBox.Show("Вы уверены, что хотите удалить расписание?", "Внимание", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                entities1.Schedule.RemoveRange(remove);
                entities1.SaveChanges();

                ScheduleGrid.ItemsSource = entities1.Schedule.ToList();
                MessageBox.Show("Записи удалены");
            }
            else
            {
                MessageBox.Show("Записи не удалены))");
            }
        }

        private void Button_Click_8(object sender, RoutedEventArgs e) //изменение расписания
        {
            if (ComboSchedule.Text != "" && DataSchedule.Text != "")
            {
                try
                {
                    var add = entities1.Emploee.Where(a => a.Name == ComboSchedule.Text).FirstOrDefault();

                    schedule.Emploee_ID = add.ID;
                    schedule.Time = Convert.ToDateTime(DataSchedule.Text.Trim());

                    entities1.Schedule.Add(schedule);
                    entities1.SaveChanges();
                    ScheduleGrid.ItemsSource = entities1.Schedule.ToList();
                }
                catch
                {
                    MessageBox.Show("Проверьте правильность введенных данных");
                }
            }
            else
            {
                MessageBox.Show("Заполните пустые поля");
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Atelier.Windows
{
    /// <summary>
    /// Логика взаимодействия для Avtorize.xaml
    /// </summary>
    public partial class Avtorize : Window
    {
        public Avtorize()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (log.Text == "0000" && pass.Text == "0000")
            {
                AdminWin adminWin = new AdminWin();
                this.Close();
                adminWin.ShowDialog();
            }
            else
            {
                MessageBox.Show("Логин - 0000, Пароль - 0000"); //просто для проверки
            }
        }
    }
}
